from flask import Flask, jsonify
from flask_cors import CORS
from ip import get_weather

app = Flask(__name__)
CORS(app)

@app.route("/api/weather", methods=["GET"])
def weather_api():
    data = get_weather()
    return jsonify(data)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
