import os
import pandas as pd
import numpy as np
import requests
import joblib
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import matplotlib.pyplot as plt
from datetime import date

# ------------------------------------------------------------
# LOAD SEASONAL MODEL + SCALER
# ------------------------------------------------------------
season_model = joblib.load("seasonal_model.pkl")
season_scaler = joblib.load("seasonal_scaler.pkl")

season_crop_map = {
    "summer": ["Tomato", "Cotton", "Bajra", "Groundnut"],
    "monsoon": ["Paddy", "Maize", "Sugarcane", "Soybean"],
    "winter": ["Wheat", "Barley", "Mustard", "Peas"]
}

# ------------------------------------------------------------
# STEP 1 — Get Coordinates
# ------------------------------------------------------------
def get_city_coordinates(city_name, api_key):
    url = f"http://api.openweathermap.org/geo/1.0/direct?q={city_name}&limit=1&appid={api_key}"
    data = requests.get(url).json()

    if not data:
        print(f"❌ City not found: {city_name}")
        return None, None

    lat, lon = data[0]["lat"], data[0]["lon"]
    print(f"\n🌍 Auto-detected Location: {city_name} (Lat: {lat}, Lon: {lon})")
    return lat, lon

# ------------------------------------------------------------
# STEP 2 — Fetch Real-Time Weather
# ------------------------------------------------------------
def fetch_current_weather(lat, lon, api_key):
    url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={api_key}&units=metric"
    data = requests.get(url, timeout=10).json()

    temp = data["main"]["temp"]
    humidity = data["main"]["humidity"]
    rain = data.get("rain", {}).get("1h", 0) or 0

    print(f"✔ Live weather fetched → Temp: {temp}°C, Humidity: {humidity}%, Rain: {rain}mm")

    return {
        "T2M": round(temp, 2),
        "RH2M": round(humidity, 2),
        "PRECTOTCORR": round(rain, 2),
        "Day": pd.to_datetime(date.today()).day_name(),
        "date": pd.to_datetime(date.today()),
        "Source": "Real Weather"
    }

# ------------------------------------------------------------
# STEP 3 — Load Historical Weather Data
# ------------------------------------------------------------
df = pd.read_csv("cleaned_weather.csv")
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date")

features = ["T2M", "PRECTOTCORR", "RH2M"]
scaler = MinMaxScaler()
scaled = scaler.fit_transform(df[features])

# ------------------------------------------------------------
# STEP 4 — Prepare LSTM Data
# ------------------------------------------------------------
n_past = 30
n_future = 7

X, y = [], []
for i in range(n_past, len(scaled) - n_future):
    X.append(scaled[i - n_past:i])
    y.append(scaled[i:i + n_future])

X, y = np.array(X), np.array(y).reshape(len(y), n_future * len(features))

# ------------------------------------------------------------
# STEP 5 — Build & Train LSTM
# ------------------------------------------------------------
print("\n🧠 Training LSTM model...\n")

model = Sequential([
    LSTM(128, activation="relu", input_shape=(X.shape[1], X.shape[2])),
    Dropout(0.2),
    Dense(64, activation="relu"),
    Dense(y.shape[1])
])

model.compile(optimizer="adam", loss="mse")
model.fit(X, y, epochs=60, batch_size=16, verbose=1)

print("\n🔥 Model training completed!\n")

# ------------------------------------------------------------
# STEP 6 — Predict Next 6 Days
# ------------------------------------------------------------
def predict_forecast():
    last_seq = scaler.transform(df[features].tail(30))
    pred_scaled = []
    current = last_seq.copy()

    for _ in range(n_future - 1):
        pred = model.predict(current.reshape(1, 30, 3), verbose=0)[0][:3]
        pred_scaled.append(pred)
        current = np.vstack([current[1:], pred])

    future = scaler.inverse_transform(pred_scaled)

    dates = pd.date_range(date.today() + pd.Timedelta(days=1), periods=6)
    fc = pd.DataFrame(future, columns=features)
    fc["Day"] = dates.day_name()
    fc["date"] = dates
    fc["Source"] = "LSTM Forecast"
    fc["PRECTOTCORR"] = fc["PRECTOTCORR"].clip(lower=0)
    return fc

# ------------------------------------------------------------
# STEP 7 — Seasonal Suitability
# ------------------------------------------------------------
def get_season_suitability(temp, humidity, rain):
    arr = np.array([[temp, humidity, rain]])
    scaled_input = season_scaler.transform(arr)

    pred = season_model.predict(scaled_input)[0]
    prob = season_model.predict_proba(scaled_input)[0]

    return pred, {
        "summer": round(prob[list(season_model.classes_).index("summer")] * 100, 2),
        "monsoon": round(prob[list(season_model.classes_).index("monsoon")] * 100, 2),
        "winter": round(prob[list(season_model.classes_).index("winter")] * 100, 2),
    }

# ------------------------------------------------------------
# STEP 8 — Pretty Print Table
# ------------------------------------------------------------
def print_forecast_table(df):
    print("\n\n📅  DAY-WISE FORECAST:\n")
    print(f"{'Day':<12}{'Temperature (°C)':<18}{'Rainfall (mm)':<15}{'Humidity (%)':<15}{'Source'}")
    print("-" * 70)

    for _, row in df.iterrows():
        print(f"{row['Day']:<12}{row['T2M']:<18.2f}{row['PRECTOTCORR']:<15.2f}{row['RH2M']:<15.2f}{row['Source']}")

# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
if __name__ == "__main__":
    API_KEY = "7868bad434b0a5ce387ac455d7347fce"

    city = input("\n🏙 Enter your city name: ").strip()

    lat, lon = get_city_coordinates(city, API_KEY)
    today = fetch_current_weather(lat, lon, API_KEY)

    # ---------- SEASONAL SUITABILITY ----------
    predicted_season, scores = get_season_suitability(
        today["T2M"], today["RH2M"], today["PRECTOTCORR"]
    )

    print("\n🌱 Seasonal Suitability")
    print("----------------------------------------")
    print(f"Summer Crops  : {scores['summer']}% fit")
    print(f"Monsoon Crops : {scores['monsoon']}% fit")
    print(f"Winter Crops  : {scores['winter']}% fit")

    print("\n🌾 Weather-Based Crop Suggestions\n")
    for crop in season_crop_map[predicted_season]:
        print(f"👉 {crop} — Perfect for current weather")

    # ---------- 7-DAY FORECAST ----------
    forecast = predict_forecast()
    full_df = pd.concat([pd.DataFrame([today]), forecast])

    print("\n" + "=" * 70)
    print(f"🌦 7-DAY WEATHER FORECAST SUMMARY FOR {city.upper()} ({date.today()})")
    print("=" * 70)

    print(f"Average Temperature : {full_df['T2M'].mean():.2f} °C")
    print(f"Total Rainfall      : {full_df['PRECTOTCORR'].sum():.2f} mm")
    print(f"Average Humidity    : {full_df['RH2M'].mean():.2f} %")

    print_forecast_table(full_df)

    # SAVE
    folder = f"forecasts/{city}_{date.today()}"
    os.makedirs(folder, exist_ok=True)
    full_df.to_csv(f"{folder}/forecast_output.csv", index=False)

    print(f"\n📁 Data saved successfully in → {folder}\n")
