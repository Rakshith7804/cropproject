import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib
from datetime import datetime

# Generate synthetic weather data for different seasons
np.random.seed(42)

# Create seasonal data
seasons_data = []

# Summer (March-May): High temp, moderate humidity, variable rainfall
summer_data = {
    'temperature': np.random.normal(32, 3, 300),
    'humidity': np.random.normal(55, 10, 300),
    'rainfall': np.random.exponential(8, 300),
    'season': 'summer'
}
seasons_data.append(pd.DataFrame(summer_data))

# Monsoon (June-September): High temp, high humidity, high rainfall
monsoon_data = {
    'temperature': np.random.normal(28, 2, 400),
    'humidity': np.random.normal(80, 8, 400),
    'rainfall': np.random.exponential(25, 400),
    'season': 'monsoon'
}
seasons_data.append(pd.DataFrame(monsoon_data))

# Winter (October-February): Moderate temp, low humidity, low rainfall
winter_data = {
    'temperature': np.random.normal(22, 3, 300),
    'humidity': np.random.normal(45, 8, 300),
    'rainfall': np.random.exponential(3, 300),
    'season': 'winter'
}
seasons_data.append(pd.DataFrame(winter_data))

# Combine all seasonal data
df = pd.concat(seasons_data, ignore_index=True)

# Add some noise and ensure realistic ranges
df['temperature'] = np.clip(df['temperature'], 15, 45)
df['humidity'] = np.clip(df['humidity'], 20, 95)
df['rainfall'] = np.clip(df['rainfall'], 0, 100)

# Features for the model
features = ['temperature', 'humidity', 'rainfall']

# Prepare data for training
X = df[features]
y = df['season']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Scale the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train Random Forest Classifier
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train_scaled, y_train)

# Evaluate the model
train_accuracy = model.score(X_train_scaled, y_train)
test_accuracy = model.score(X_test_scaled, y_test)

print(f"Training Accuracy: {train_accuracy:.3f}")
print(f"Test Accuracy: {test_accuracy:.3f}")

# Save the model and scaler
joblib.dump(model, 'seasonal_model.pkl')
joblib.dump(scaler, 'seasonal_scaler.pkl')

print("Seasonal suitability model trained and saved!")

# Test the model with sample data
sample_data = pd.DataFrame({
    'temperature': [32, 28, 22],
    'humidity': [55, 80, 45],
    'rainfall': [8, 25, 3]
})

sample_scaled = scaler.transform(sample_data)
predictions = model.predict(sample_scaled)
probabilities = model.predict_proba(sample_scaled)

print("\nSample Predictions:")
for i, (pred, probs) in enumerate(zip(predictions, probabilities)):
    print(f"Sample {i+1}: {pred.capitalize()} season")
    print(f"  Probabilities: Summer={probs[2]:.3f}, Monsoon={probs[0]:.3f}, Winter={probs[1]:.3f}")
