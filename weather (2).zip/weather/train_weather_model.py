import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import joblib
import os

# Generate synthetic weather data for training
def generate_weather_data():
    np.random.seed(42)
    dates = pd.date_range('2020-01-01', periods=1000, freq='D')

    # Generate realistic weather patterns
    base_temp = 25 + 5 * np.sin(2 * np.pi * np.arange(1000) / 365)  # Seasonal variation
    temperature = base_temp + np.random.normal(0, 3, 1000)

    # Humidity correlated with temperature
    humidity = 70 - 0.5 * (temperature - 25) + np.random.normal(0, 5, 1000)
    humidity = np.clip(humidity, 30, 90)

    # Rainfall - more in monsoon season
    month = pd.to_datetime(dates).month
    rainfall_prob = np.where((month >= 6) & (month <= 9), 0.3, 0.1)
    rainfall = np.random.exponential(5, 1000) * (np.random.random(1000) < rainfall_prob)
    rainfall = np.clip(rainfall, 0, 50)

    df = pd.DataFrame({
        'date': dates,
        'temperature': temperature,
        'humidity': humidity,
        'rainfall': rainfall
    })

    return df

# Prepare data for LSTM
def prepare_data(data, lookback=7):
    X, y = [], []
    for i in range(len(data) - lookback):
        X.append(data[i:(i + lookback)])
        y.append(data[i + lookback])
    return np.array(X), np.array(y)

# Train weather prediction model
def train_weather_model():
    print("Generating weather data...")
    df = generate_weather_data()

    # Select features for prediction
    features = ['temperature', 'humidity', 'rainfall']
    data = df[features].values

    # Scale the data
    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(data)

    # Save scaler
    joblib.dump(scaler, 'weather_scaler.pkl')

    # Prepare sequences
    lookback = 7  # Use 7 days to predict next day
    X, y = prepare_data(scaled_data, lookback)

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Build LSTM model
    model = Sequential([
        LSTM(50, return_sequences=True, input_shape=(lookback, len(features))),
        Dropout(0.2),
        LSTM(50, return_sequences=False),
        Dropout(0.2),
        Dense(len(features))
    ])

    model.compile(optimizer='adam', loss='mse')

    print("Training weather prediction model...")
    model.fit(X_train, y_train, epochs=50, batch_size=32, validation_split=0.1, verbose=1)

    # Save model in Keras format (more compatible)
    model.save('weather_model.keras')
    print("Model trained and saved successfully!")

    return model, scaler

if __name__ == "__main__":
    train_weather_model()
